export const recipes = [
  {
    id: 1,
    title: "Paneer Butter Masala",
    category: "Indian",
    image: "https://link-to-image.jpg",
    ingredients: [
      "200g paneer", "2 onions", "2 tomatoes", "1 tbsp butter", "Spices"
    ],
    steps: [
      "Onion-tomato puree banayein.",
      "Butter mein puree bhunein.",
      "Paneer add karein aur 10 min tak cook karein."
    ],
    videoUrl: "https://www.youtube.com/embed/xyz123"
  },
];