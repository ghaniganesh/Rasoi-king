import React from 'react';
import { Link } from 'react-router-dom';

export default function RecipeCard({ recipe }) {
  return (
    <Link to={`/recipe/${recipe.id}`}>
      <div className="rounded-xl shadow-md p-4 bg-white hover:shadow-lg">
        <img src={recipe.image} alt={recipe.title} className="rounded-md w-full h-40 object-cover" />
        <h2 className="mt-2 font-bold text-lg">{recipe.title}</h2>
        <p className="text-sm text-gray-500">{recipe.category}</p>
      </div>
    </Link>
  );
}