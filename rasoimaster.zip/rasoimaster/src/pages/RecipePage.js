import React from 'react';
import { useParams } from 'react-router-dom';
import { recipes } from '../data';

export default function RecipePage() {
  const { id } = useParams();
  const recipe = recipes.find(r => r.id === parseInt(id));

  if (!recipe) return <p>Recipe not found</p>;

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold">{recipe.title}</h1>
      <img src={recipe.image} className="my-4 rounded-md" alt={recipe.title} />
      <h2 className="text-xl font-semibold mt-4">📝 Ingredients:</h2>
      <ul className="list-disc list-inside">
        {recipe.ingredients.map((item, index) => <li key={index}>{item}</li>)}
      </ul>

      <h2 className="text-xl font-semibold mt-4">👨‍🍳 Steps:</h2>
      <ol className="list-decimal list-inside">
        {recipe.steps.map((step, index) => <li key={index}>{step}</li>)}
      </ol>

      <h2 className="text-xl font-semibold mt-4">🎥 Watch Video:</h2>
      <iframe
        className="w-full h-64 mt-2"
        src={recipe.videoUrl}
        title="Recipe Video"
        frameBorder="0"
        allowFullScreen
      />
    </div>
  );
}